package com.example.speedometer

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.JsonReader
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.Reader
import kotlin.concurrent.thread
import kotlinx.coroutines.delay as delay1

class Galileo : AppCompatActivity() {
        val UUID:String="fc7ca420-c971-4b1d-9b09-6f61abe22b05"
        lateinit var BlueDevice: BluetoothDevice

companion object{
    val selectedaddress:String="hello world"
    var isconnected:Boolean=false
    var isfound:Boolean=false
    lateinit var Bsocket:BluetoothSocket
    lateinit var Output:OutputStream
    lateinit var Input:InputStream
    const val MESSAGE_READ: Int = 0
    const val MESSAGE_WRITE: Int = 1
    const val MESSAGE_TOAST: Int = 2
}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_galileo2)
        BluetoothInitialization()
    }
     fun BluetoothInitialization(){
        var blueadapt:BluetoothAdapter= BluetoothAdapter.getDefaultAdapter()
        if(blueadapt==null)
        {
            println("This device does not support bluetooth")
        }
        if(!blueadapt.isEnabled) {
            val blueadaptIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivity(blueadaptIntent)
            try{
                Thread.sleep(1000)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }
        var setofdevices:Set<BluetoothDevice> = blueadapt.bondedDevices
         if(setofdevices.isEmpty())
         {
             println("Must pair devices first")
         }
         else
         {
          for(BluetoothDevice in setofdevices)
             {
                 if(BluetoothDevice.address==selectedaddress)
                 {
                     BlueDevice=BluetoothDevice
                     isfound=true
                     break

                 }
             }
         }
    }
    fun BlueConnect(){
        if(isfound)
        {
            try {
             Bsocket=BlueDevice.createInsecureRfcommSocketToServiceRecord(java.util.UUID.randomUUID())
                Bsocket.connect()
            }
            catch(e:IOException) {
                e.printStackTrace()
                isconnected=false
            }
            if(isconnected) {
                try {
                    Output= Bsocket.outputStream
                } catch(e:IOException) {
                    e.printStackTrace()
                }
                try {
                    Input= Bsocket.inputStream
                }catch (e:IOException)
                {
                e.printStackTrace()
            }
            }
        }
    }
    class MyBluetoothService(
        // handler that gets info from Bluetooth service
        private val handler: Handler
    ) {

        private inner class ConnectedThread(private val mmSocket: BluetoothSocket) : Thread() {

            private val mmInStream: InputStream = mmSocket.inputStream
            private val mmOutStream: OutputStream = mmSocket.outputStream
            private val mmBuffer: ByteArray = ByteArray(1024) // mmBuffer store for the stream

            @SuppressLint("LongLogTag")
            override fun run() {
                var numBytes: Int // bytes returned from read()

                // Keep listening to the InputStream until an exception occurs.
                while (true) {
                    // Read from the InputStream.
                    numBytes = try {
                        mmInStream.read(mmBuffer)
                    } catch (e: IOException) {
                        Log.i("Input stream was disconnected", e.toString())
                        break
                    }

                    // Send the obtained bytes to the UI activity.
                    val readMsg = handler.obtainMessage(
                        MESSAGE_READ, numBytes, -1,
                        mmBuffer)
                    val conversionVariable:Reader?=readMsg.
                    JsonReader().toString()
                    readMsg.sendToTarget()
                }
            }

            // Call this from the main activity to send data to the remote device.
            @SuppressLint("LongLogTag")
            fun write(bytes: ByteArray) {
                try {
                    mmOutStream.write(bytes)
                } catch (e: IOException) {
                    Log.e("Error occurred when sending data", e.toString())

                    // Send a failure message back to the activity.
                    val writeErrorMsg = handler.obtainMessage(MESSAGE_TOAST)
                    val bundle = Bundle().apply {
                        putString("toast", "Couldn't send data to the other device")
                    }
                    writeErrorMsg.data = bundle
                    handler.sendMessage(writeErrorMsg)
                    return
                }

                // Share the sent message with the UI activity.
                val writtenMsg = handler.obtainMessage(
                    MESSAGE_WRITE, -1, -1, mmBuffer)
                writtenMsg.sendToTarget()
            }

            // Call this method from the main activity to shut down the connection.
            @SuppressLint("LongLogTag")
            fun cancel() {
                try {
                    mmSocket.close()
                } catch (e: IOException) {
                    Log.e("Could not close the connect socket", e.toString())
                }
            }
        }
    }
    //Allows the user to view the speedometer and the odometer
    //Allows the user to set the wheel diameter
}
