package com.example.speedometer

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlin.concurrent.thread
import kotlinx.coroutines.delay as delay1

class Galileo : AppCompatActivity() {
        val UUID:String="fc7ca420-c971-4b1d-9b09-6f61abe22b05"
        lateinit var BlueDevice: BluetoothDevice


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_galileo2)
        BluetoothInitialization()
    }
     fun BluetoothInitialization(){
        var blueadapt:BluetoothAdapter= BluetoothAdapter.getDefaultAdapter()
        if(blueadapt==null)
        {
            println("This device does not support bluetooth")
        }
        if(!blueadapt.isEnabled) {
            val blueadaptIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivity(blueadaptIntent)
            try{
                Thread.sleep(1000)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }
        var setofdevices:Set<BluetoothDevice> = blueadapt.bondedDevices
         if(setofdevices.isEmpty())
         {
             println("Must pair devices first")
         }
         else
         {
             
         }
    }

    //Allows the user to view the speedometer and the odometer
    //Allows the user to set the wheel diameter
}
