package com.example.speedometer

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothAdapter.ACTION_DISCOVERY_STARTED
import android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

class BluetoothDeviceList : AppCompatActivity() {

    lateinit var blueadapt:BluetoothAdapter
    class BroadcastReciever: BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            var action: String = intent!!.action.toString()
            Log.i("Action", action)
            if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED == action)
            {

            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bluetooth_device_list)
    //Search.setOnClickListener{val searchintent= Intent(this, )
      //  startActivity(searchintent)}
        //connect.setOnClickListener{val connectintent=Intent(this,)
        //startActivity(connectintent)}
        var intentfilter:IntentFilter=IntentFilter()
       blueadapt=BluetoothAdapter.getDefaultAdapter()
        intentfilter.addAction(ACTION_STATE_CHANGED)
        intentfilter.addAction(BluetoothDevice.ACTION_FOUND)
        intentfilter.addAction(ACTION_DISCOVERY_STARTED)
        intentfilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        registerReceiver(BroadcastReciever(),intentfilter)
        blueadapt.startDiscovery()
    }

    //We will produce a List View that can be updated with the Bluetooth Devices in the Area
    //Must be able to select a Bluetooth Device and connect to the device
    //Will use Udemy code as baseline and all about circuits code
}
