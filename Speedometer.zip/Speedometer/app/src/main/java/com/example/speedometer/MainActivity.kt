package com.example.speedometer

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem

import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.content_main.*

class MainActivity : AppCompatActivity() {
    companion object {
        var WheelDiameter: Double = 0.0
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
        BikeData.setOnClickListener { val bikeIntent= Intent(this,Galileo::class.java )
        startActivity(bikeIntent)}
        TrueBlueManager.setOnClickListener { val manageIntent= Intent(this, BluetoothDeviceList::class.java)
        startActivity(manageIntent)}
        Updater.setOnClickListener {UpdateWheel()}
        }
    fun UpdateWheel() {
        if (wheelDiam.text != null) {
            val conversionVariable: Editable = wheelDiam.text
            val stringvar: String = conversionVariable.toString()
            val doublevar:Double=stringvar.toDouble()
            WheelDiameter=doublevar

        }
        else{
            println("please enter a new wheel diameter")
        }
    }
}
