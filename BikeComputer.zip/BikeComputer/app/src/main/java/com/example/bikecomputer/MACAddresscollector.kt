package com.example.bikecomputer

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import kotlinx.android.synthetic.main.activity_addresscollector.*
import org.jetbrains.anko.toast
class MACAddresscollector : AppCompatActivity() {
    companion object {
        lateinit var maddress: String
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_addresscollector)
        button.setOnClickListener{MACfunction(macaddressinput.text)}
        backbutton.setOnClickListener{val mainIntent= Intent(this, MainActivity::class.java )
        startActivity(mainIntent)}
    }
    private fun MACfunction(input:Editable)
    {
        if(macaddressinput!=null)
        {
            if(macaddressinput.length()==17)
            {
                val conversionvariable: Editable =input
                maddress=conversionvariable.toString()
                toast("MAC Address Successfully Updated")
            }
            else{
                toast("Your MAC address is invalid, check that you have inputted it correctly")
            }
        }
    }

}
