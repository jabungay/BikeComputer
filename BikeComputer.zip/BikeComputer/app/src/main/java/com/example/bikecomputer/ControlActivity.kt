package com.example.bikecomputer
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity
import com.example.bikecomputer.MACAddresscollector.Companion.maddress
import kotlinx.android.synthetic.main.activity_control.*
import java.io.IOException
import java.util.*
import org.jetbrains.anko.toast

class ControlActivity : AppCompatActivity() {
    companion object {
        private var manage_BluetoothAdapt: BluetoothAdapter? = null
        private lateinit var setofdevices: Set<BluetoothDevice>
        var my_UUID: UUID = UUID.fromString("bee50a2d-b5bb-4011-becf-140b47038b64")
        var Bsocket: BluetoothSocket? = null
        lateinit var progress: ProgressBar//Needs to be replaced with ProgressBar as Progress Dialog is deprecated
        lateinit var Badapter: BluetoothAdapter
        var isConnected: Boolean = false
         var address1:String= maddress
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_control)
        if(maddress!=null) {
            address1 = maddress
        }
        else{
        toast("Need to fill in MAC address")
            Thread.sleep(3000)
            val macIntent= Intent(this, MACAddresscollector::class.java)
            startActivity(macIntent)
        }
    }


    private fun disconnect() {
        if (Bsocket != null)

            try {
                Bsocket!!.close()
                Bsocket = null
                isConnected = false
            } catch (e: IOException) {
                e.printStackTrace()
            }
        finish()
    }

    private class connectToDevice(c: Context) : AsyncTask<Void, Void, String>() {
        private var ConnectSuccess: Boolean = true
        private val context: Context

        init {
            this.context = c
        }

        override fun onPreExecute() {
            super.onPreExecute()

        }

        override fun doInBackground(vararg params: Void?): String? {
            try {
                if (!isConnected) {
                    Badapter = BluetoothAdapter.getDefaultAdapter()
                    address1 = maddress
                    setofdevices=Badapter.bondedDevices
                    if(setofdevices.isEmpty())
                    {
                        print("pair device")
                    }

                    val device: BluetoothDevice = Badapter.getRemoteDevice(address1)
                    Bsocket = device.createInsecureRfcommSocketToServiceRecord(my_UUID)
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery()
                    Bsocket!!.connect()
                }
            } catch (e: IOException) {
                ConnectSuccess = false
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (!ConnectSuccess) {
                Log.i("data", "Not working")
            } else {
                isConnected = true
            }
        }
        }
    }