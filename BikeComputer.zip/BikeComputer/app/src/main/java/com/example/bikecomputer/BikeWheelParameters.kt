package com.example.bikecomputer

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_bike_wheel_parameters.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream

class BikeWheelParameters : AppCompatActivity() {
    var Bluesocket: BluetoothSocket? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        blueConnect(this).execute()
        setContentView(R.layout.activity_bike_wheel_parameters)
        UpdateParams.setOnClickListener { senddata(newDiamNumber.text) }
        //input parameter for the send data must be the fillable text field
    }

    private fun recievedata() {
        lateinit var output:String
        if(Bluesocket !=null) {
            try {
                var conversionVar: InputStream = Bluesocket!!.inputStream
                val available=conversionVar.available()
                val Bytes:ByteArray= ByteArray(available)
                conversionVar.read(Bytes,0,available)
                val text=String(Bytes)
                output=text
            } catch(e:IOException) {
            e.printStackTrace()
            }

        }
        currWheelDiam.text = output
    }



    fun senddata(input: Editable) {
        if (Bluesocket != null) {
            try {
                var conversionVar: String = input.toString()
                Bluesocket!!.outputStream.write(conversionVar.toByteArray())
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        //Takes Text data inputted into field and converts to proper format for serial data transmission
        //Checks that bluetooth is connected
        //Sends data via serial data transmission
    }

    class blueConnect(c: Context) : AsyncTask<Void, Void, String>() {
        private var ConnectSuccess: Boolean = true
        private val context: Context

        init {
            this.context = c
        }

        override fun onPreExecute() {
            super.onPreExecute()
        }

        override fun doInBackground(vararg params: Void?): String? {
            try {
                if (!ControlActivity.isConnected) {
                    if(BluetoothAdapter.getDefaultAdapter()!=null) {
                        ControlActivity.Badapter = BluetoothAdapter.getDefaultAdapter()
                        val device: BluetoothDevice = ControlActivity.Badapter.getRemoteDevice(
                            ControlActivity.address1
                        )


                        ControlActivity.Bsocket = device.createInsecureRfcommSocketToServiceRecord(
                            ControlActivity.my_UUID
                        )
                        BluetoothAdapter.getDefaultAdapter().cancelDiscovery()
                        ControlActivity.Bsocket!!.connect()
                    }
                }
            } catch (e: IOException) {
                ConnectSuccess = false
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (!ConnectSuccess) {
                Log.i("data", "Not working")
            } else {
                ControlActivity.isConnected = true
            }
        }

    }
}

        //Uses BluetoothManagement activity functions to ensure bluetooth connectivity
        //Allows for the receive function to work properly
