package com.example.bikecomputer
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.bikecomputer.ControlActivity.Companion.Badapter
import com.example.bikecomputer.ControlActivity.Companion.Bsocket
import com.example.bikecomputer.ControlActivity.Companion.address1
import com.example.bikecomputer.ControlActivity.Companion.isConnected
import com.example.bikecomputer.ControlActivity.Companion.my_UUID
import kotlinx.android.synthetic.main.activity_bike_wheel_parameters.*
import java.io.IOException
import java.io.InputStream

class BikeDataView : AppCompatActivity() {
    var Bluesocket:BluetoothSocket?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bike_data_view)
        connectblue(this).execute()
        while(Bluesocket!=null)
        {
            receivedata()
        }

    }

    private fun receivedata() {
        lateinit var output:String
        if(Bluesocket !=null) {
            try {
                var conversionVar: InputStream = Bluesocket!!.inputStream
                val available=conversionVar.available()
                val Bytes:ByteArray= ByteArray(available)
                conversionVar.read(Bytes,0,available)
                val text=String(Bytes)
                output=text
            } catch(e:IOException) {
                e.printStackTrace()
            }

        }

        //Ensures bluetooth is connected using connect blue function
        //Proceeds to receive serial data from the Intel Galileo in an agreed upon format
        //Display data in text field using appropriate conversion
    }

    private class connectblue(c: Context) : AsyncTask<Void, Void, String>() {
        private var ConnectSuccess: Boolean = true
        private val context: Context

        init {
            this.context = c
        }

        override fun onPreExecute() {
            super.onPreExecute()
        }

        override fun doInBackground(vararg params: Void?): String? {
            try {
                if (!isConnected) {
                    Badapter = BluetoothAdapter.getDefaultAdapter()
                    val device: BluetoothDevice = Badapter.getRemoteDevice(address1)
                    Bsocket = device.createInsecureRfcommSocketToServiceRecord(my_UUID)
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery()
                    Bsocket!!.connect()
                }
            } catch (e: IOException) {
                ConnectSuccess = false
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (!ConnectSuccess) {
                Log.i("data", "Not working")
            } else {
                isConnected = true
            }
        }

    }
}
    //Uses BluetoothManagement activity functions to ensure bluetooth connectivity
    //Allows for the receive function to work properly