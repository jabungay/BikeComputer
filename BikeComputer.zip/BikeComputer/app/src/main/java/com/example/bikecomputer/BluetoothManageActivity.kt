package com.example.bikecomputer

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.os.Bundle
import android.text.AlteredCharSequence.make
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_bluetooth_manage.*
import kotlinx.android.synthetic.main.content_bluetooth_manage.*
import org.jetbrains.anko.toast

class BluetoothManageActivity : AppCompatActivity() {
    companion object {
        private var manage_BluetoothAdapt: BluetoothAdapter? = null
        private lateinit var setofdevices: Set<BluetoothDevice>
        private val Request_Enable_Bluetooth = 1
        val ExtraAddress: String = "Device_Address"
        lateinit var viewManager: RecyclerView
        lateinit var viewAdapter: RecyclerView.Adapter<*>
        lateinit var viewmanager: RecyclerView.LayoutManager
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bluetooth_manage)
        setSupportActionBar(toolbar)
        manage_BluetoothAdapt = BluetoothAdapter.getDefaultAdapter()
        viewmanager = LinearLayoutManager(this)
        if (manage_BluetoothAdapt == null) {
            toast("this device does not support bluetooth")
            return
        }
        if (!manage_BluetoothAdapt!!.isEnabled) {
            val EnableBluetoothIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(EnableBluetoothIntent, Request_Enable_Bluetooth)
        }
        /*viewmanager = LinearLayoutManager(this)
        refresh.setOnClickListener() { paireddevicelist() }
        fab.setOnClickListener { view ->
            make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()*/
        }



        fun paireddevicelist() {/*
            setofdevices = manage_BluetoothAdapt!!.bondedDevices
            val list: ArrayList<BluetoothDevice> = ArrayList()
            if (setofdevices.isNotEmpty()) {
                for (device: BluetoothDevice in setofdevices) {
                    list.add(device)
                    Log.i("device", "device")
                }
            } else {
                toast("no devices are paired")
            }
            if()
                val device: BluetoothDevice=
                val address: String = device.address
                val intent = Intent(this, ControlActivity::class.java)
                intent.putExtra(ExtraAddress, address)
                startActivity(intent) */
            }


        override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
            super.onActivityResult(requestCode, resultCode, data)
            if (requestCode == Request_Enable_Bluetooth) {
                if (resultCode == Activity.RESULT_OK) {
                    if (manage_BluetoothAdapt!!.isEnabled) {
                        toast("Bluetooth is enabled")
                    } else {
                        toast("Bluetooth is disabled")
                    }
                } else if (resultCode == Activity.RESULT_CANCELED)
                    toast("Bluetooth has been cancelled")
            }
        }

        public class MyAdapter(private val myDataset: Array<String>) :
            RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
            class MyViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView)

            // Create new views (invoked by the layout manager)
            override fun onCreateViewHolder(
                parent: ViewGroup,
                viewType: Int
            ): MyAdapter.MyViewHolder {
                // create a new view
                val textView = LayoutInflater.from(parent.context)
                    .inflate(R.layout.content_bluetooth_manage, parent, false) as TextView
                // set the view's size, margins, paddings and layout parameters

                return MyViewHolder(textView)
            }

            override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
                // - get element from your dataset at this position
                // - replace the contents of the view with that element
                holder.textView.text = myDataset[position]
            }

            // Return the size of your dataset (invoked by the layout manager)
            override fun getItemCount() = myDataset.size
        }
    }
