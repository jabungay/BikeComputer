package com.example.bikecomputer
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Params.setOnClickListener{val paramsIntent = Intent(this, BikeWheelParameters::class.java)
            startActivity(paramsIntent)}
        Bikedata.setOnClickListener{ val dataIntent = Intent(this, BikeDataView::class.java)
            startActivity(dataIntent)}
        MAC.setOnClickListener{val macIntent= Intent(this, MACAddresscollector::class.java)
        startActivity(macIntent)}
        DeviceManager.setOnClickListener { val deviceIntent=Intent(this, BluetoothManagement::class.java)
        startActivity(deviceIntent)}

    }

}

