../gradlew check
