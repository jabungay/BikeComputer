rootProject.name = "klaxon-root"

include("klaxon", "klaxon-jackson")
