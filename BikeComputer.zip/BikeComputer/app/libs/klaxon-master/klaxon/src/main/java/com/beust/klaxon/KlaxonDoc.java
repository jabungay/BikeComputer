package com.beust.klaxon;

/**
 * Dummy file to generate a Javadoc artifact.
 */
public class KlaxonDoc {

}