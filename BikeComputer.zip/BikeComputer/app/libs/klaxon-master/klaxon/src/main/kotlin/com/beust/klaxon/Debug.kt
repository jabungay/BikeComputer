package com.beust.klaxon

class Debug {
    companion object {
        val verbose = false
    }
}