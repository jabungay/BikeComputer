package com.beust.klaxon

/*
import java.io.InputStream
import java.io.OutputStream
import java.io.Reader
import java.io.Writer
import javax.json.*
import javax.json.spi.JsonProvider
import javax.json.stream.JsonGenerator
import javax.json.stream.JsonGeneratorFactory
import javax.json.stream.JsonParser
import javax.json.stream.JsonParserFactory

class KlaxonJsonProvider: JsonProvider() {
    override fun createGenerator(p0: Writer?): JsonGenerator {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createGenerator(p0: OutputStream?): JsonGenerator {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createReaderFactory(p0: MutableMap<String, *>?): JsonReaderFactory {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createWriter(p0: Writer?): JsonWriter {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createWriter(p0: OutputStream?): JsonWriter {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createParser(p0: Reader?): JsonParser {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createParser(p0: InputStream?): JsonParser {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createGeneratorFactory(p0: MutableMap<String, *>?): JsonGeneratorFactory {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createObjectBuilder(): JsonObjectBuilder {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createArrayBuilder(): JsonArrayBuilder {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createReader(p0: Reader?): JsonReader {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createReader(p0: InputStream?): JsonReader {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createWriterFactory(p0: MutableMap<String, *>?): JsonWriterFactory {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createBuilderFactory(p0: MutableMap<String, *>?): JsonBuilderFactory {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createParserFactory(p0: MutableMap<String, *>?): JsonParserFactory {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

}
        */